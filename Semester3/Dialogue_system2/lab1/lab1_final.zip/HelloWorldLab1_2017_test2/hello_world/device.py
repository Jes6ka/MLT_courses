from tdm.lib.device import DddDevice, DeviceWHQuery, DeviceAction


class HelloWorldDevice(DddDevice):
    def __init__(self):
        self.reset()
        
    def reset(self):
        self._time_hour = 00
        self._time_minute = 00
        self._alarm_hour = 00
        self._alarm_minute = 00
        self._alarm_is_set = False
        self._alarm_off_message = "alarm_off_default_string"

    class current_time(DeviceWHQuery):
        def perform(self):
            time = '"%02d:%02d"' % (self.device._time_hour, self.device._time_minute)
            return [time]

    class alarm_time(DeviceWHQuery):
        def perform(self):
            time = '"%02d:%02d"' % (self.device._alarm_hour, self.device._alarm_minute)
            return [time]

    class alarm_status(DeviceWHQuery):
        def perform(self):
            time = '"%s"' % (self.device._alarm_is_set)
            return [time]

    class alarm_off(DeviceWHQuery):
        def perform(self):
            
            if self.device._alarm_is_set == False:
                message = "Alarm is already off."
            else:
                self.device._alarm_off_message = "Alarm is off now."
                self.device._alarm_is_set = False
                message = '"%s"' % (self.device._alarm_off_message)
            return [message]

    class oneshot_order(DeviceWHQuery):
        def perform(self):
            time = '"%s"' % ("Jesus Christ")
            return [time]
			
    class SetTime(DeviceAction):
        PARAMETERS = ["hour_to_set", "minute_to_set"]
        def perform(self, hour, minute):
            self.device._time_hour = hour
            self.device._time_minute = minute
            return True

    class SetAlarm(DeviceAction):
        PARAMETERS = ["hour_to_set", "minute_to_set"]
        def perform(self, hour, minute):
            self.device._alarm_hour = hour
            self.device._alarm_minute = minute
            self.device._alarm_is_set = True
            return True

    class SetTimeOneshot(DeviceAction):
        PARAMETERS = ["hour_to_set", "minute_to_set"]
        def perform(self, hour, minute):
            self.device._time_hour = hour
            self.device._time_minute = minute
            return True

    class SetAlarmOneshot(DeviceAction):
        PARAMETERS = ["hour_to_set", "minute_to_set"]
        def perform(self, hour, minute):
            self.device._alarm_hour = hour
            self.device._alarm_minute = minute
            self.device._alarm_is_set = True
            return True