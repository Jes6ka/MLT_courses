from tdm.lib.device import DddDevice, DeviceWHQuery, DeviceAction
from urllib2 import Request,urlopen
import json

class WeatherDevice(DddDevice):

    def __init__(self):
        self.target_city      = "london"
        self.target_country   = "uk"
        self.target_city_temp = "unknown_temp" 
        self.target_city_weather = "unknown_weather" 


    def getData(self,city,country):
        url = 'http://api.openweathermap.org/data/2.5/weather?q=%s,%s&APPID=6682255239356a0cca7132d6027d8c41' % (city,country)
        print url
        request = Request(url)
        response = urlopen(request)
        data = response.read()
        return json.loads(data)
    ###########Get temperature#############

    # class print_temperature(DeviceWHQuery):
    #     def perform(self):
    #         time = '"Temperature of %s is %s degree"' % (self.device.target_city, self.device.target_city_temp)
    #         return [time]

    # class print_weather(DeviceWHQuery):
    #     def perform(self):
    #         time = '"Weather of %s is %s"' % (self.device.target_city, self.device.target_city_weather)
    #         return [time]



    ###########Get temperature#############

    class get_temperature(DeviceWHQuery):
        PARAMETERS = ["city_to_search", "country_to_search"]

        def perform(self,city,country):
            self.device.target_city = city 
            self.device.target_country = country 

            data = self.device.getData(city, country)
            temp = data['main']['temp']
            #temp = data['weather']['main']
            tempstr = str(temp)
            return [tempstr]



    ###########Get weather#############

    class get_weather(DeviceWHQuery):
        PARAMETERS = ["city_to_search", "country_to_search"]

        def perform(self,city,country):
            self.device.target_city = city 
            self.device.target_country = country 

            data = self.device.getData(city, country)
            #temp = data['main']['temp']
            temp = data['weather'][0]['main']
            tempstr = str(temp)
            return [tempstr]
